package testcases;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.GiftCardPage;

public class GiftCardTest extends BaseTest {

    Logger log = Logger.getLogger(GiftCardTest.class);
    GiftCardPage giftCardPage;

    @BeforeClass
    public void initPageObject() {
        giftCardPage = new GiftCardPage(driver);
    }

    // =========================
    // Test Case 1
    // Verify Gift Card section opens
    // =========================
    @Test
    public void verifyGiftCardSectionOpensTest() throws InterruptedException {

        log.info("===== Test Case 1: Verify Gift Card Section Opens Started =====");

        log.info("Opening EaseMyTrip home page");
        driver.get("https://www.easemytrip.com/");

        log.info("Opening Gift Card section");
        giftCardPage.openGiftCardSection();

        log.info("Verifying Gift Card form is visible");
        Assert.assertTrue(giftCardPage.isGiftCardFormVisible(), "Gift Card form is not visible");

        log.info("===== Test Case 1 Passed =====");
    }

    // =========================
    // Test Case 2
    // Verify Gift Card form submission attempt
    // =========================
    @Test(dependsOnMethods = "verifyGiftCardSectionOpensTest")
    public void verifyGiftCardFormSubmissionAttemptTest() throws InterruptedException {

        log.info("===== Test Case 2: Verify Gift Card Form Submission Attempt Started =====");

        log.info("Filling Gift Card details with invalid email");
        giftCardPage.fillGiftCardDetails("500", "1", "Adam", "abc@", "9876543210");

        log.info("Verifying Pay Now button is visible");
        Assert.assertTrue(giftCardPage.isPayNowButtonVisible(), "Pay Now button is not visible");

        log.info("Clicking Same as Sender, Accept Terms and Pay Now");
        giftCardPage.selectCheckboxesAndPay();

        log.info("===== Test Case 2 Passed =====");
    }

    // =========================
    // Test Case 3
    // Verify invalid email error message
    // =========================
    @Test(dependsOnMethods = "verifyGiftCardFormSubmissionAttemptTest")
    public void verifyInvalidEmailErrorMessageTest() {

        log.info("===== Test Case 3: Verify Invalid Email Error Message Started =====");

        log.info("Capturing invalid email error message");
        String error = giftCardPage.getErrorMessage();

        System.out.println("Captured Error Message: " + error);
        log.info("Captured Error Message: " + error);

        Assert.assertNotNull(error, "Error message is null");
        Assert.assertFalse(error.trim().isEmpty(), "Error message is empty");
        Assert.assertEquals(error.trim(), "Email address is required and it should be valid.");

        log.info("===== Test Case 3 Passed =====");
    }
}