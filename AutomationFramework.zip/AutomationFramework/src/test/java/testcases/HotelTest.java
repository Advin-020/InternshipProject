package testcases;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.HotelPage;

public class HotelTest extends BaseTest {

    Logger log = Logger.getLogger(HotelTest.class);
    HotelPage hotelPage;
    List<Integer> adultCounts;

    @BeforeClass
    public void initPageObject() {
        hotelPage = new HotelPage(driver);
    }

    // =========================
    // Test Case 1
    // Verify hotel page loads
    // =========================
    @Test
    public void verifyHotelPageLoadsTest() {

        log.info("===== Test Case 1: Verify Hotel Page Loads Started =====");

        log.info("Opening Hotel page");
        hotelPage.openHotelPage();

        log.info("Verifying Rooms & Guests section is visible");
        Assert.assertTrue(hotelPage.isGuestSelectorVisible(),
                "Rooms & Guests section is not visible on hotel page");

        log.info("===== Test Case 1 Passed =====");
    }

    // =========================
    // Test Case 2
    // Verify guest selection panel opens
    // =========================
    @Test(dependsOnMethods = "verifyHotelPageLoadsTest")
    public void verifyGuestSelectionOpensTest() throws InterruptedException {

        log.info("===== Test Case 2: Verify Guest Selection Opens Started =====");

        log.info("Opening Rooms & Guests section");
        hotelPage.openGuestSelection();

        log.info("Verifying guest selection panel is visible");
        Assert.assertTrue(hotelPage.isGuestSelectionOpen(), "Guest selection panel did not open");

        log.info("===== Test Case 2 Passed =====");
    }

    // =========================
    // Test Case 3
    // Extract all Adult count values
    // =========================
    @Test(dependsOnMethods = "verifyGuestSelectionOpensTest")
    public void verifyAdultCountsExtractionTest() throws InterruptedException {

        log.info("===== Test Case 3: Verify Adult Counts Extraction Started =====");

        log.info("Extracting all Adult count values");
        adultCounts = hotelPage.extractAllAdultCounts();

        System.out.println("Extracted Adult Counts: " + adultCounts);
        log.info("Extracted Adult Counts: " + adultCounts);

        Assert.assertNotNull(adultCounts, "Adult counts list is null");
        Assert.assertTrue(adultCounts.size() > 0, "Adult counts list is empty");

        log.info("===== Test Case 3 Passed =====");
    }

    // =========================
    // Test Case 4
    // Validate extracted Adult count list
    // =========================
    @Test(dependsOnMethods = "verifyAdultCountsExtractionTest")
    public void verifyAdultCountsListValidationTest() {

        log.info("===== Test Case 4: Verify Adult Counts List Validation Started =====");

        Assert.assertNotNull(adultCounts, "Adult counts list is null");
        Assert.assertTrue(adultCounts.size() > 0, "Adult counts list is empty");

        log.info("Checking duplicate Adult count values");
        Set<Integer> uniqueValues = new HashSet<>(adultCounts);
        Assert.assertEquals(uniqueValues.size(), adultCounts.size(),
                "Duplicate adult counts found in the list");

        log.info("Checking minimum Adult count");
        Assert.assertEquals((int) adultCounts.get(0), 1, "Minimum adult count should be 1");

        log.info("Checking Adult count sequence");
        for (int i = 1; i < adultCounts.size(); i++) {
            Assert.assertEquals((int) adultCounts.get(i), adultCounts.get(i - 1) + 1,
                    "Adult counts are not in proper increasing sequence");
        }

        int maximumCount = adultCounts.get(adultCounts.size() - 1);
        log.info("Checking maximum Adult count");
        Assert.assertTrue(maximumCount >= 2, "Maximum adult count is invalid");

        log.info("Validated Adult Counts: " + adultCounts);
        log.info("Minimum Adult Count: " + adultCounts.get(0));
        log.info("Maximum Adult Count: " + maximumCount);

        log.info("===== Test Case 4 Passed =====");
    }
}