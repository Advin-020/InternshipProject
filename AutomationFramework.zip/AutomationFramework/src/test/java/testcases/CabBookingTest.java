package testcases;

import java.util.List;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.CabPage;

public class CabBookingTest extends BaseTest {

    Logger log = Logger.getLogger(CabBookingTest.class);
    CabPage cabPage;

    @BeforeClass
    public void initPageObject() {
        cabPage = new CabPage(driver);
    }

    // =========================
    // Test Case 1
    // Verify outstation cab search results load
    // =========================
    @Test
    public void verifyOutstationCabSearchResultsLoadTest() throws InterruptedException {

        log.info("===== Test Case 1: Verify Cab Search Results Load Started =====");

        log.info("Opening cab page");
        cabPage.openCabPage();

        log.info("Selecting one way outstation trip");
        cabPage.selectOutstationOneWay();

        log.info("Selecting route from Delhi to Manali");
        cabPage.selectRoute("Delhi", "Manali");

        log.info("Selecting pickup date: 29-07-2026");
        cabPage.selectPickupDate("29-07-2026");

        log.info("Selecting pickup time: 06:30 AM");
        cabPage.selectPickupTime("06:30 AM");

        log.info("Clicking Search button");
        cabPage.clickSearch();

        log.info("Verifying SUV filter is visible after search");
        Assert.assertTrue(cabPage.isSUVFilterVisible(), "SUV filter is not visible after search");

        log.info("===== Test Case 1 Passed =====");
    }

    // =========================
    // Test Case 2
    // Verify SUV filter and More Options are available
    // =========================
    @Test(dependsOnMethods = "verifyOutstationCabSearchResultsLoadTest")
    public void verifySUVFilterAndMoreOptionsAvailabilityTest() throws InterruptedException {

        log.info("===== Test Case 2: Verify SUV Filter and More Options Started =====");

        log.info("Applying SUV filter");
        cabPage.applySUVFilter();

        log.info("Verifying More Options link is visible");
        Assert.assertTrue(cabPage.isMoreOptionsVisible(), "More Options link is not visible after applying SUV filter");

        log.info("===== Test Case 2 Passed =====");
    }

    // =========================
    // Test Case 3
    // Verify lowest SUV price extraction
    // =========================
    @Test(dependsOnMethods = "verifySUVFilterAndMoreOptionsAvailabilityTest")
    public void verifyLowestSUVPriceExtractionTest() throws InterruptedException {

        log.info("===== Test Case 3: Verify Lowest SUV Price Extraction Started =====");

        log.info("Extracting all SUV fare prices from More Options");
        List<Integer> allPrices = cabPage.getAllPrices();
        log.info("All extracted SUV prices: " + allPrices);

        int lowestPrice = cabPage.getLowestPrice(allPrices);
        log.info("Lowest SUV price found: " + lowestPrice);

        Assert.assertNotNull(allPrices, "Price list is null");
        Assert.assertTrue(allPrices.size() > 0, "No SUV prices were found");
        Assert.assertTrue(lowestPrice > 0, "Lowest SUV price is invalid");

        System.out.println("All SUV Prices: " + allPrices);
        System.out.println("Lowest SUV Price: " + lowestPrice);

        log.info("===== Test Case 3 Passed =====");
    }
}