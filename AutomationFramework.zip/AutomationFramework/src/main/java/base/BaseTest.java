package base;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import utilities.DriverFactory;

public class BaseTest {

    protected WebDriver driver;

    @BeforeClass
    public void setUp() {
        driver = DriverFactory.getDriver();
        driver.get("https://www.easemytrip.com/");
    }

    @AfterClass
    public void tearDown() {
        DriverFactory.quitDriver();
    }
}