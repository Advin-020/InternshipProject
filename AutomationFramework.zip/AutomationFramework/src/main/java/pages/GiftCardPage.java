package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import java.time.Duration;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GiftCardPage {

    WebDriver driver;
    Actions action;
    WebDriverWait wait;

    public GiftCardPage(WebDriver driver) {
        this.driver = driver;
        this.action = new Actions(driver);
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }
    
    // =========================
    // Navigation Locators
    // =========================

    // Navigation
    By moreMenu = By.xpath("//span[contains(@class,'moremenuico') and contains(@class,'more')]");
    By buyGiftCardsHere = By.xpath("//span[contains(text(),'Buy giftcards here')]");
    By basicGiftCard = By.xpath("//img[contains(@src,'emt-14.png') and contains(@alt,'EaseMyTrip')]");

    // Form fields
    By amountField = By.xpath("//input[@placeholder='Min 500 -  50000']");
    By quantityDropdown = By.xpath("//select[contains(@class,'drp_dwn')]");
    By senderNameField = By.xpath("//input[contains(@placeholder,\"Sender's name\") or contains(@placeholder,'Sender Name')]");
    By senderEmailField = By.id("txtEmailId");
    By senderMobileField = By.xpath("//input[contains(@placeholder,'Sender') and contains(@placeholder,'mobile')]");

    // Checkboxes and button
    By sameAsSenderCheckbox = By.xpath("(//input[@type='checkbox' and contains(@class,'lite-blue-check')])[1]");
    By acceptTermsCheckbox = By.xpath("(//input[@type='checkbox' and contains(@class,'lite-blue-check')])[2]");
    By payNowButton = By.id("pny");

    // Error message
    By errorMessage = By.xpath("//p[contains(@class,'err_msg') and contains(text(),'Email address')]");

    // =========================
    // Gift Card Page Actions
    // =========================

    public void openGiftCardSection() throws InterruptedException {
        HomePage homePage = new HomePage(driver);
        homePage.goToGiftCards();

        driver.findElement(basicGiftCard).click();
    }

    public void fillGiftCardDetails(String amount, String quantity, String senderName, String senderEmail, String senderMobile) throws InterruptedException {
        driver.findElement(amountField).sendKeys(amount);

        Select quantitySelect = new Select(driver.findElement(quantityDropdown));
        quantitySelect.selectByVisibleText(quantity);

        driver.findElement(senderNameField).sendKeys(senderName);
        driver.findElement(senderEmailField).sendKeys(senderEmail);
        driver.findElement(senderMobileField).sendKeys(senderMobile);
    }

    public void selectCheckboxesAndPay() throws InterruptedException {
        driver.findElement(sameAsSenderCheckbox).click();

        driver.findElement(acceptTermsCheckbox).click();

        driver.findElement(payNowButton).click();
    }

    // =========================
    // Helper Methods for GiftCardTest
    // =========================

    public boolean isGiftCardFormVisible() {
        return driver.findElement(amountField).isDisplayed();
    }

    public boolean isPayNowButtonVisible() {
        return driver.findElement(payNowButton).isDisplayed();
    }

    public String getErrorMessage() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(errorMessage));
        return driver.findElement(errorMessage).getText().trim();
    }
}