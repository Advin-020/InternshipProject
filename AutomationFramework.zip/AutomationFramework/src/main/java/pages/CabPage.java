package pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CabPage {

    WebDriver driver;
    WebDriverWait wait;

    public CabPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    // =========================
    // Cab Search Locators
    // =========================

    By oneWayTab = By.id("li5");

    // Location input fields
    By fromCityOpener = By.id("sourceName");
    By fromCityInput = By.id("a_FromSector_show");
    By toCityInput = By.id("a_ToSector_show");
    By firstSuggestion = By.xpath("(//div[@class='auto_sugg_tttl'])[1]");

    // Date picker locators
    By pickupDateField = By.id("datepicker");
    By pickupDate29 = By.xpath("//div[@id='ui-datepicker-div']//a[text()='29']");

    // Time picker locators
    By pickupTimeField = By.id("time");
    By sixHourOption = By.xpath("//div[@id='hr']//li[contains(text(),'6 Hr.')]");
    By thirtyMinOption = By.xpath("//div[@id='min']//li[contains(text(),'30 Min.')]");
    By amOption = By.xpath("//label[@for='am']");
    By doneButton = By.xpath("//div[contains(@class,'done_d') and contains(text(),'Done')]");

    // Search button
    By searchButton = By.xpath("//*[@id='CommonSearch']//div[contains(text(),'SEARCH') or contains(text(),'Search')]");

    // =========================
    // Search Result Locators
    // =========================

    // SUV filter on result page
    By suvFilter = By.xpath("//*[@id=\"body\"]/app-root/div[3]/ng-component/div[2]/section[2]/div/div/div[1]/div/div[3]/div[2]/label[3]/div[1]/span[2]");
    By moreOptionsLink = By.xpath("(//a[contains(text(),'More Options')])[1]");
    By fareValueWrap = By.xpath("//div[contains(@class,'fare-value-wrap')]");
    By popupPriceElements = By.xpath("//div[contains(@class,'fare-value-wrap')]//label[contains(@class,'fare')]//div[contains(@class,'ruppes')]//h6");

    // =========================
    // Cab Page Navigation
    // =========================

    public void openCabPage() throws InterruptedException {
        HomePage homePage = new HomePage(driver);
        homePage.goToCabs();
    }

    // =========================
    // Cab Search Actions
    // =========================

    public void selectOutstationOneWay() throws InterruptedException {
        // Wait until the cab page is loaded
        wait.until(ExpectedConditions.elementToBeClickable(oneWayTab)).click();
    }

    public void selectRoute(String fromCity, String toCity) throws InterruptedException {
        // Open From city input
        driver.findElement(fromCityOpener).click();

        // Enter From city
        WebElement fromInput = driver.findElement(fromCityInput);
        fromInput.sendKeys(fromCity);
        Thread.sleep(2000);

        // Select first suggestion for From city
        driver.findElement(firstSuggestion).click();

        // Enter To city
        WebElement toInput = driver.findElement(toCityInput);
        toInput.sendKeys(toCity);
        Thread.sleep(2000);

        // Select first suggestion for To city
        driver.findElement(firstSuggestion).click();
    }

    public void selectPickupDate(String date) throws InterruptedException {
        driver.findElement(pickupDateField).click();
        driver.findElement(pickupDate29).click();
    }

    public void selectPickupTime(String time) throws InterruptedException {
        // Time picker is custom UI, so 6:30 AM is selected using hour, minute and AM controls.
        driver.findElement(pickupTimeField).click();

        driver.findElement(sixHourOption).click();// Select 6 hour
        driver.findElement(thirtyMinOption).click();// Select 30 minutes
        driver.findElement(amOption).click();// Select AM
        driver.findElement(doneButton).click();// Confirm selected time
    }

    public void clickSearch() throws InterruptedException {
        driver.findElement(searchButton).click();

        // Wait until result page loads and SUV filter becomes visible.
        wait.until(ExpectedConditions.visibilityOfElementLocated(suvFilter));
    }

    // =========================
    // Search Result Actions
    // =========================

    public void applySUVFilter() throws InterruptedException {
        driver.findElement(suvFilter).click();
    }

    // Helper function used in CabBookingTest
    public boolean isSUVFilterVisible() {
        return driver.findElement(suvFilter).isDisplayed();
    }

    // Helper function used in CabBookingTest
    public boolean isMoreOptionsVisible() {
        return driver.findElement(moreOptionsLink).isDisplayed();
    }

    public List<Integer> getAllPrices() {
        List<Integer> allPrices = new ArrayList<>();

        // Click More Options to show all SUV fare options
        WebElement moreOptions = wait.until(ExpectedConditions.elementToBeClickable(moreOptionsLink));
        moreOptions.click();

        // Wait until all price elements are visible in the popup
        List<WebElement> priceList = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(popupPriceElements));

        // Convert price text into integer values
        for (WebElement price : priceList) {
            String priceText = price.getText().replaceAll("[^0-9]", "");

            if (!priceText.isEmpty()) {
                try {
                    allPrices.add(Integer.parseInt(priceText));
                } catch (NumberFormatException e) {
                    // Ignore non-price text if found unexpectedly.
                }
            }
        }
        return allPrices;
    }

    public int getLowestPrice(List<Integer> prices) {
        int lowest = Integer.MAX_VALUE;

        // Traverse the list of prices to find the lowest price
        for (int price : prices) {
            if (price < lowest) {
                lowest = price;
            }
        }

        return lowest == Integer.MAX_VALUE ? 0 : lowest;
    }
}