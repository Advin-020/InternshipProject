package pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HotelPage {

    WebDriver driver;

    public HotelPage(WebDriver driver) {
        this.driver = driver;
    }

    // =========================
    // Hotel Page Locators
    // =========================

    // Main Rooms & Guests section on hotel page
    By guestSelector = By.xpath("//div[contains(@class,'hp_inputBox') and contains(@class,'roomGuests')]");

    // Guest selection popup/panel
    By guestSelectionPanel = By.id("divHotelPaxContent");

    // Adult controls
    By adultCountValue = By.id("Adults_room_1_1");
    By increaseAdultButton = By.id("Adults_room_1_1_plus");
    By decreaseAdultButton = By.id("Adults_room_1_1_minus");

    // Done button
    By doneButton = By.id("exithotelroom");

    public void openHotelPage() {
        HomePage homePage = new HomePage(driver);
        homePage.goToHotels();
    }

    // =========================
    // Hotel Page Actions
    // =========================

    public boolean isGuestSelectorVisible() {
        return driver.findElement(guestSelector).isDisplayed();
    }

    public void openGuestSelection() throws InterruptedException {
        driver.findElement(guestSelector).click();
    }

    public boolean isGuestSelectionOpen() {
        return driver.findElement(guestSelectionPanel).isDisplayed();
    }

    public int getCurrentAdultCount() {
        String count = driver.findElement(adultCountValue).getText().trim();
        return Integer.parseInt(count);
    }

    public List<Integer> extractAllAdultCounts() throws InterruptedException {
        List<Integer> adultCounts = new ArrayList<>();

        // Step 1: move to minimum value first
        while (true) {
            int before = getCurrentAdultCount();

            driver.findElement(decreaseAdultButton).click();

            int after = getCurrentAdultCount();

            if (before == after) {
                break;
            }
        }

        // Step 2: collect all values from minimum to maximum
        while (true) {
            int before = getCurrentAdultCount();
            adultCounts.add(before);

            driver.findElement(increaseAdultButton).click();

            int after = getCurrentAdultCount();

            if (before == after) {
                break;
            }
        }

        return adultCounts;
    }

    public void closeGuestSelection() throws InterruptedException {
        driver.findElement(doneButton).click();
    }
}