package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePage {

    WebDriver driver;
    Actions action;
    WebDriverWait wait;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        this.action = new Actions(driver);
    }

    // =========================
    // Home Page Navigation Locators
    // =========================

    By cabsTab = By.xpath("//*[contains(text(),'Cabs')]");
    By hotelsTab = By.xpath("//*[normalize-space()='Hotels']");

    // Gift Card navigation locators
    By moreMenu = By.xpath("//span[contains(@class,'moremenuico') and contains(@class,'more')]");
    By buyGiftCardsHere = By.xpath("//span[contains(text(),'Buy giftcards here')]");

    // =========================
    // Navigation Actions
    // =========================

    public void goToCabs() {
        driver.findElement(cabsTab).click();
    }

    public void goToHotels() {
        driver.findElement(hotelsTab).click();
    }

    public void goToGiftCards() {
        WebElement more = driver.findElement(moreMenu);
        action.moveToElement(more).perform();

        wait.until(ExpectedConditions.elementToBeClickable(buyGiftCardsHere)).click();
    }
}