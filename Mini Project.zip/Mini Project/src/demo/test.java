package demo;

import org.testng.Assert;
import org.testng.annotations.*;

public class test {

    @BeforeClass
    public void setup() {

        //initialize browser 
        String browser = "edge";

        if (browser.equalsIgnoreCase("chrome")) {
            OrangeHRM.driver = new org.openqa.selenium.chrome.ChromeDriver();
        } else {
            OrangeHRM.driver = new org.openqa.selenium.edge.EdgeDriver();
        }

        OrangeHRM.driver.manage().window().maximize();
        OrangeHRM.driver.manage().timeouts().implicitlyWait(java.time.Duration.ofSeconds(5));

        OrangeHRM.driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");

        //login only
        OrangeHRM.login();
    }

    @Test(priority = 1)
    public void testJobCategory() {
    	
    	//add and delete job
        OrangeHRM.handleJobCategory();

        boolean result = OrangeHRM.isItemPresent("Test Engineer");

        Assert.assertFalse(result, "Job Category not deleted");
        System.out.println("--Job Category Test Passed");
    }

    @Test(priority = 2)
    public void testLocation() {
    	
    	//add and delete location
        OrangeHRM.handleLocation();

        boolean result = OrangeHRM.isItemPresent("Test Location");

        Assert.assertFalse(result, "Location not deleted");
        System.out.println("--Location Test Passed");
    }

    @Test(priority = 3)
    public void testSkill() {
    
    	//add and delete skill
        OrangeHRM.handleSkill();

        boolean result = OrangeHRM.isItemPresent("Testing Demo");

        Assert.assertFalse(result, "Skill not deleted");
        System.out.println("--Skill Test Passed");
    }

    @AfterClass
    public void teardown() {
        //logout at end
        OrangeHRM.logout();
        OrangeHRM.driver.quit();
    }
}