package demo;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;
import java.time.Duration;

public class OrangeHRM {
    static WebDriver driver;

    public static void main(String[] args) {

        String browser = "edge";

        //Multi browser handling
        if (browser.equalsIgnoreCase("chrome")) {
            driver = new ChromeDriver();
        } else {
            driver = new EdgeDriver();
        }

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        
        login();
        handleJobCategory();
        handleLocation();
        handleSkill();
        logout();

        driver.quit();
    }
    

    //LOGIN
    public static void login() {
        driver.findElement(By.name("username")).sendKeys("Admin");
        driver.findElement(By.name("password")).sendKeys("admin123");
        driver.findElement(By.tagName("button")).click();

        System.out.println("Login Successful");
    }
    
    //LOGOUT
    public static void logout() {
    	
    	//select user dropdown , than click logout
        driver.findElement(By.xpath("//p[@class='oxd-userdropdown-name']")).click();
        driver.findElement(By.xpath("//a[text()='Logout']")).click();

        System.out.println("Logout Successful");
    }

    //NAVIGATE ADMIN
    public static void goToAdmin() {
        driver.findElement(By.xpath("//span[text()='Admin']")).click();
    }

    //JOB CATEGORY
    public static void handleJobCategory() {
    	
        goToAdmin();
        
        //select job than job categories
        driver.findElement(By.xpath("//span[text()='Job ']")).click();
        driver.findElement(By.xpath("//a[text()='Job Categories']")).click();
        
        //click add to go to add job page
        driver.findElement(By.xpath("//button[text()=' Add ']")).click();
        
        //Type the Job Category and click add
        driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[2]/input")).sendKeys("Test Engineer");
        driver.findElement(By.xpath("//button[@type='submit']")).click();
                
        deleteItem("Test Engineer");
        
        System.out.println("Job Category Completed");
    }

    //LOCATION
    public static void handleLocation() {

        goToAdmin();
        
        //select Organization and click locations
        driver.findElement(By.xpath("//span[text()='Organization ']")).click();
        driver.findElement(By.xpath("//a[text()='Locations']")).click();
        
        //click add to go to add page
        driver.findElement(By.xpath("//button[text()=' Add ']")).click();
        
        //add location info
        driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div/div/div[2]/input")).sendKeys("Test Location");
        //click county to get dropdown option , than click 'India'
        driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[2]/div/div[4]/div/div[2]/div/div")).click();
        driver.findElement(By.xpath("//span[text()='India']")).click();
        
        //submit the info
        driver.findElement(By.xpath("//button[@type='submit']")).click();
        
        deleteItem("Test Location");

        System.out.println("Location Completed");
    }

    //SKILL
    public static void handleSkill() {

        goToAdmin();
        
        //click qualification , than Skills
        driver.findElement(By.xpath("//span[text()='Qualifications ']")).click();
        driver.findElement(By.xpath("//a[text()='Skills']")).click();
        
        //click add to get to add Skills page
        driver.findElement(By.xpath("//button[text()=' Add ']")).click();

        //Type the Skills info, and submit
        driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[2]/input")).sendKeys("Testing Demo");
        driver.findElement(By.xpath("//button[@type='submit']")).click();

        deleteItem("Testing Demo");

        System.out.println("Skill Completed");
    }

 // DELETE
    public static void deleteItem(String value) {
    	
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='table']")));

        List<WebElement> rows = driver.findElements(By.xpath("//div[@role='row']"));

        for (WebElement row : rows) {
            if (row.getText().contains(value)) {

                row.findElement(By.xpath(".//button[contains(@class,'oxd-icon-button')]")).click();

                driver.findElement(By.xpath("//button[text()=' Yes, Delete ']")).click();
                break;
            }
        }
    }
    
    //VERIFICATION METHOD
    public static boolean isItemPresent(String value) {

	    List<WebElement> rows = driver.findElements(By.xpath("//div[@role='row']"));
	
	    for (WebElement row : rows) {
	        if (row.getText().contains(value)) {
	            return true;
	        }
	    }
	    return false;
}



}